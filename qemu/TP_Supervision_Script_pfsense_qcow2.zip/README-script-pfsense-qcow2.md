# Script libvirt/QEMU avec pfSense qcow2 démarré en premier

Ce script remplace/améliore `create-debian12-vms-libvirt.sh`.

## Objectif

- Télécharger ou utiliser une image pfSense qcow2 déjà prête.
- Créer deux réseaux libvirt :
  - `TP-SUPERV-WAN` : NAT/DHCP pour le WAN pfSense.
  - `TP-SUPERV-LAN` : LAN isolé `192.168.1.0/24` pour le TP.
- Créer et démarrer la VM pfSense en premier.
- Créer ensuite les VMs Debian 12 avec passerelle `192.168.1.1`.

## Identifiants pfSense du laboratoire

- Login : `admin`
- Mot de passe : `pfsense`

## Utilisation

```bash
chmod +x create-vms-libvirt-with-pfsense.sh
sudo ./create-vms-libvirt-with-pfsense.sh
```

## Si le téléchargement Mega échoue

Télécharger manuellement l'image qcow2 puis la placer ici :

```bash
/home/$USER/tp-supervision/pfsense-lab-base.qcow2
```

Puis relancer :

```bash
sudo ./create-vms-libvirt-with-pfsense.sh
```

## Si les interfaces pfSense ne montent pas en virtio

Relancer avec des cartes Intel e1000 :

```bash
sudo PFSENSE_WAN_MODEL=e1000 PFSENSE_LAN_MODEL=e1000 ./create-vms-libvirt-with-pfsense.sh
```
